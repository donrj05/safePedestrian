import os
import pandas as pd
from flask import Flask, request, jsonify, render_template
from openai import OpenAI
from dotenv import load_dotenv
from datetime import datetime
import pytz

load_dotenv()

df = pd.read_csv("wow.csv")
app = Flask(__name__)
#Dont use my credits
client = OpenAI(api_key="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")
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message')

    if is_route_query(user_input):
        start, end, time_of_day = extract_query_details(user_input)
        dangerous_routes_summary = find_dangerous_routes(start, end, time_of_day)

        if dangerous_routes_summary == "No dangerous routes detected.":
            google_maps_link = get_google_maps_link(start+", NYC", end+" NYC")
            context = f"No dangerous pedestrian routes detected between {start} and {end} at {time_of_day}. The route is safe for pedestrians to take at this time of the day. You can check the route here: {google_maps_link}"
        else:
            safer_route_prompt = (f"Suggest a safer pedestrian route between {start} and {end}, "
                                  f"avoiding the following dangerous areas: {dangerous_routes_summary}. "
                                  f"Suggest a path that would ensure pedestrian safety.")
            safer_route_response = get_gpt_response(safer_route_prompt)

            if "no safer route" in safer_route_response.lower() or "cannot find" in safer_route_response.lower():
                context = "I couldn't devise a safer route. Please proceed with caution or use a different route."
            else:
                context = f"Avoid the dangerous routes between {start} and {end}. Based on analysis, a safer route is suggested. You can view the safer route here: {google_maps_link}\n{safer_route_response}"
    else:
        context = f"User query: {user_input}\nAnswer:"

    gpt_response = get_gpt_response(context)
    
    return jsonify({"response": gpt_response})

def is_route_query(query):
    """Determine if the query is about finding a route, even with natural language patterns."""
    query = query.lower()
    route_keywords = ["from", "to", "go to", "get to", "navigate to", "find route to"]
    for keyword in route_keywords:
        if keyword in query:
            return True
    return False

def extract_query_details(query):
    """Extract start, end, and time from user query."""
    words = query.split()
    start, end, time_of_day = "", "", ""
    for i, word in enumerate(words):
        if word.lower() == "from" and i + 1 < len(words):
            start = words[i + 1]
        elif word.lower() == "to" and i + 1 < len(words):
            end = words[i + 1]
        elif word.lower() == "at" and i + 1 < len(words):
            time_of_day = words[i + 1]

    if time_of_day:
        time_of_day = infer_time_of_day(time_of_day)
    else:
        time_of_day = get_local_est_time_of_day()
    
    return start, end, time_of_day

def get_local_est_time_of_day():
    """Determine time of day based on local EST time."""
    est = pytz.timezone('America/New_York')
    current_time = datetime.now(est).strftime('%H:%M:%S')

    if "06:00:00" <= current_time <= "11:59:59":
        return "morning"
    elif "12:00:00" <= current_time <= "17:59:59":
        return "afternoon"
    elif "18:00:00" <= current_time <= "21:59:59":
        return "evening"
    else:
        return "night"

def infer_time_of_day(time_input):
    """Use GPT to infer the time of day from user input."""
    prompt = (f"Classify the time '{time_input}' into one of these categories: morning, afternoon, evening, or night.")
    gpt_response = get_gpt_response(prompt)

    valid_times = ["morning", "afternoon", "evening", "night"]

    inferred_time = gpt_response.strip().lower()
    if inferred_time not in valid_times:
        return "evening"
    return inferred_time

def get_google_maps_link(start, end, safer_route=False):
    """Generate Google Maps link for directions or a safer route if available."""
    base_url = "https://www.google.com/maps/dir/"
    start_formatted = start.replace(" ", "+")
    end_formatted = end.replace(" ", "+")

    if safer_route:
        return f"{base_url}{start_formatted}/{end_formatted}?avoid=highways&avoid=tolls"
    else:
        return f"{base_url}{start_formatted}/{end_formatted}"

def find_dangerous_routes(start, end, time_of_day):
    """Find the most dangerous routes and summarize for GPT."""
    time_ranges = {
        "morning": ("06:00:00", "11:59:59"),
        "afternoon": ("12:00:00", "17:59:59"),
        "evening": ("18:00:00", "21:59:59"),
        "night": ("22:00:00", "05:59:59")
    }

    start_time, end_time = time_ranges[time_of_day]
    time_filtered = df[(df['OCCUR_TIME'] >= start_time) & (df['OCCUR_TIME'] <= end_time)]

    route_incidents = time_filtered[(time_filtered['Address'].str.contains(start, case=False, na=False)) |
                                     (time_filtered['Address'].str.contains(end, case=False, na=False))]
    
    if route_incidents.empty:
        return "No dangerous routes detected."
    else:
        summary_data = route_incidents[['Address', 'OCCUR_TIME', 'BORO']].head(5).to_dict(orient='records')
        summary_text = "\n".join([f"Address: {row['Address']}, Time: {row['OCCUR_TIME']}, Borough: {row['BORO']}"
                                    for row in summary_data])
        
        return f"Most dangerous routes:\n{summary_text}"

def get_gpt_response(prompt):
    """Get GPT response using OpenAI API."""
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a helpful assistant specialized in identifying safe pedestrian routes."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content

if __name__ == '__main__':
    app.run(debug=True, port=5004)
